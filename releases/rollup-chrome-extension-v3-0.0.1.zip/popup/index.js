import '../button-de7b316d.js';

let o=document.getElementById("changeColor");function e(){chrome.storage.sync.get("color",(({color:o})=>{document.body.style.backgroundColor=o;}));}chrome.storage.sync.get("color",(({color:e})=>{o.style.backgroundColor=e;})),o.addEventListener("click",(async()=>{let[o]=await chrome.tabs.query({active:!0,currentWindow:!0});chrome.scripting.executeScript({target:{tabId:o.id},function:e});}));
