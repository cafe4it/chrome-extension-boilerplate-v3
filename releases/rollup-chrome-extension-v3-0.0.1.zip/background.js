chrome.runtime.onInstalled.addListener((()=>{chrome.storage.sync.set({color:"#3aa757"}),console.log("Default background color set to %cgreen","color: #3aa757");}));
