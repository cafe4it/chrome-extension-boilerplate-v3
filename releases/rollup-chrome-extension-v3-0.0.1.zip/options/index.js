import '../button-de7b316d.js';

let t=document.getElementById("buttonDiv");function e(t){let e=t.target.parentElement.querySelector(".current");e&&e!==t.target&&e.classList.remove("current");let r=t.target.dataset.color;t.target.classList.add("current"),chrome.storage.sync.set({color:r});}var r;r=["#3aa757","#e8453c","#f9bb2d","#4688f1"],chrome.storage.sync.get("color",(o=>{let c=o.color;for(let o of r){let r=document.createElement("button");r.dataset.color=o,r.style.backgroundColor=o,o===c&&r.classList.add("current"),r.addEventListener("click",e),t.appendChild(r);}}));
